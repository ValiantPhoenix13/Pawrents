/*
name: Andrew Lawson
date: 6 November 2022

descrition: The following is practice of taking an expression and converting it to Postfix format then evaluating the Postfix expression

self-grade: My grade is 100 sense I have proper naming throughout, comments and block comments for each method, proper indentation,
the program compiles and runs, finally I fully completed the "YourDriver" section and contains this self grading portion
Testimony: I have written this program all by myself and have not copied any code 
from any resources: Andrew Lawson
*/


import java.util.*;
public class StackLawson //<----- change this name to include your last name.
{
  // no code here
}
interface myStack
{
   public void push(String s);
   public String peek();
   public boolean isEmpty();
   public String pop();
}
/* must use array to implement the stack class*/
class  Stack  //must implement the myStack interface
{
   private  String[] s;  // Fall 2022
   private int top; // representing the element at the top
   public Stack()
   {
      s = new String[20];
      top = -1;
      
   }
   public void push(String token)
   {
      top++;
      s[top] = token;
   }
   //implement the rest of the methods based on the given description in the word doc
   
   //Returns the top element and decrements the top by one
   public String pop(){
      String temp = s[top];
      top--;
      return temp;
   }
   
   //Return the top element
   public String peek(){
      return s[top];
   }
   
   //Check to see if the stack is empty; top == -1
   public boolean isEmpty(){
      if (top == -1){
         return true;
      }
      return false;
   }
   
   //To string method
   public String toString(){
      String info = "";
      for (int i = 0; i < s.length; i++){
         info = info + s[i] + "\n";
      }
      return info;
   }
   
   
     
}

class Expression
{
   private String exp;  // instance variable
   public Expression(String s)
   {
      exp = s;
   }
   
   //Converts an expression into its Postfix format
   public String getPostfix()
   {
      String postfix = " ";
      Stack edit = new Stack();
      StringTokenizer st = new StringTokenizer(exp, " ");
      while(st.hasMoreTokens()){
         String token = st.nextToken();
         if (token.equals("+") || token.equals("-") || token.equals("/") || token.equals("*")){
            if(precedence(token) == 3){
               while(edit.isEmpty() == false && precedence(edit.peek()) == 3){
                  postfix = postfix + edit.pop() + " ";
               }
            }
            else if (precedence(token) == 2){
               while(edit.isEmpty() == false && (precedence(edit.peek()) == 2 || precedence(edit.peek()) == 3)){
                  postfix = postfix + edit.pop() + " ";
               }
            }
            edit.push(token);
         } else {
            postfix = postfix + token + " ";
         }
         
      }
      while (edit.isEmpty() == false){
         postfix = postfix + edit.pop() + " ";
      }               
      return postfix;
   }
   
   //Determines the order of operations currently in the stack
   private static int precedence(String opr)
   {
      if (opr.equals("*") || opr.equals("/")){
         return 3;
      }
      if (opr.equals("+") || opr.equals("-")){
         return 2;
      }
      return 0;
   }
   
   //Takes a converted Postfix expression and solves for the solution
   public int evalPostfix()
   {
      String post = this.getPostfix();
      Stack eval = new Stack();
      int result = 0;
      StringTokenizer st = new StringTokenizer (post, " ");
      while (st.hasMoreTokens()){
         String token = st.nextToken();
         if (token.equals("+") || token.equals("-") || token.equals("/") || token.equals("*")){
            String n1 = eval.pop();
            String n2 = eval.pop();
            int num1 = Integer.parseInt(n1);
            int num2 = Integer.parseInt(n2);
            result = calculate(token, num1, num2);
            post = result + "";
            eval.push(post);  
         } else {
            eval.push(token);        
         }
      }
      result = Integer.parseInt(eval.pop());
      return result;       
   }
    
     
  /* must use if/else. usim=ng switch will not get any credit*/
  //Checks the operation of the provided String
   private int calculate(String opr , int n1, int n2)
   {
      int solution = 0;
      char op = opr.charAt(0);
      if (op == '*'){
         solution = n1 * n2;
      }
      if (op == '/'){
         solution = n2 / n1;
      }
      if (op == '+'){
         solution = n1 + n2;
      }
      if (op == '-'){
         solution = n2 - n1;
      }
      return solution;
   }
   
}
class ExpDrive
{
   public static void main(String[] args)
   {
     
      String[] exp = new String[11];
      exp[0] = "2 + 3 + 7 * 4 - 2 / 3 + 4";
      exp[1] = "3 - 4 / 2 + 6 * 3 + 5";
      exp[2] = "5 * 6 - 8 + 2 * 10 - 12"; 
      exp[3] = "4 + 8 * 3 - 2 / 34  * 2";
      exp[4] = "2 + 5 - 3 * 2 / 3 + 16";
      exp[5] ="6 - 3 + 6 / 2 * 4 - 8 / 2"; 
      exp[6] = "2 + 3 * 6 + 5 - 3";
      exp[7] = "2 * 3 + 4  / 3 * 2 + 6";
      exp[8] = "2 * 3 + 1 - 3 * 4 * 2";
      exp[9] = "1 + 2 * 3 - 6 * 7 + 2 * 3 + 2 * 3";
      exp[10] = "23 + 5 * 6 - 2 / 4 + 8 / 2";
      for(int i = 0; i < exp.length ; i++)
      {
      
         Expression e1 = new Expression(exp[i]);
         String post = e1.getPostfix();
         int result = e1.evalPostfix();
         System.out.println("Infix: "+ exp[i] + ",  postfix: " + post + " = " + result);
      }
   }
}

     
   

 
/* create your own driver using Arraylist. Using Array you will not get any credit for it
must create an arraylist then add different expressions to the Arraylist you just created*/
class YourDriver
{
   public static void main(String[] args)
   {
      ArrayList <String> exp = new ArrayList<String>();
      //add the rest of the code
      exp.add(0, "2 + 3 + 7 * 4 - 2 / 3 + 4");
      exp.add(1, "3 - 4 / 2 + 6 * 3 + 5");
      exp.add(2, "5 * 6 - 8 + 2 * 10 - 12");
      exp.add(3, "4 + 8 * 3 - 2 / 34  * 2");
      exp.add(4, "2 + 5 - 3 * 2 / 3 + 16");
      exp.add(5, "6 - 3 + 6 / 2 * 4 - 8 / 2");
      exp.add(6, "2 + 3 * 6 + 5 - 3");
      exp.add(7, "2 * 3 + 4  / 3 * 2 + 6");
      exp.add(8, "2 * 3 + 1 - 3 * 4 * 2");
      exp.add(9, "1 + 2 * 3 - 6 * 7 + 2 * 3 + 2 * 3");
      exp.add(10, "23 + 5 * 6 - 2 / 4 + 8 / 2");
      
      for (int i = 0; i < exp.size(); i++){
         Expression e1 = new Expression(exp.get(i));
         String post = e1.getPostfix();
         int result = e1.evalPostfix();
         System.out.println("Infix: "+ exp.get(i) + ",  postfix: " + post + " = " + result);

      }
   }
}