#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdint.h>

// Function prototypes. Don't change these.
uint8_t *read_card(char *fname, int *size);
void save_jpeg(uint8_t *data, int size, char *filename);
void recover(uint8_t *data, int size);

#define RAW_FILE "card.raw"

int main()
{
    // Read the card.raw file into an array of bytes (uint8_t)
    int card_length;
    uint8_t *card_data = read_card(RAW_FILE, &card_length);

    
    // Recover the images
    recover(card_data, card_length);
    
}

uint8_t *read_card(char *filename, int *size)
{

    struct stat st;
    if (stat(filename, &st) == -1)
    {
        fprintf(stderr, "Can't get info about %s\n", filename);
        exit(1);
    }
    int len = st.st_size;
    uint8_t *raw = malloc(len * sizeof(uint8_t));
    
    FILE *fp = fopen(filename, "rb");
    if (!fp)
    {
        fprintf(stderr, "Can't open %s for reading\n", filename);
        exit(1);
    }
    
    fread(raw, 1, len, fp);
    fclose(fp);
    
    *size = len;
    return raw;
}

void save_jpeg(uint8_t *data, int size, char *filename)
{
    FILE *fp = fopen(filename, "wb");
    if (!fp)
    {
        fprintf(stderr, "Can't write to %s\n", filename);
        exit(1);
    }
    
    fwrite(data, 1, size, fp);
    fclose(fp);   
}

void recover(uint8_t *data, int size){
    int numFiles = 0;
    char fileName[10] = ".jpg"; //Sets up the file name extension for all the images
    int temp1; //variables used to check for the beginning of a jpeg
    int temp2;
    int temp3;
    int temp4;
    int loop1 = 0; //initializes the first loop that scans for the beginning signatures of a jpeg
    while (loop1<size) {
        int loop2 = 0;
        int count = 0;
        temp1 = *data; //assigning variable by pointing them to the values to test for the beginning signatures of jpeg
        temp2 = *(data+1);
        temp3 = *(data+2);
        temp4 = *(data+3);
        if (temp1 == 255 && temp2 == 216 && temp3 == 255 && temp4 == 224) {
            uint8_t *start = data; //assigns the start of the jpeg to a pointer to later save the image
            while(loop2 != 1){
                temp1 = *data;
                temp2 = *(data+1);
                temp3 = *(data+2);
                temp4 = *(data+3);
                if(temp1 == 255 && temp2 == 217 && temp3 == 0){
                    sprintf(fileName, "%03d.jpg", numFiles); //after finding the beginning look for the end signature and save
                    save_jpeg(start, count, fileName);
                    numFiles++;
                    loop2 = 1;
                }else{
                    data++;
                    count++;
                }
            }
        } else if (temp1 == 255 && temp2 == 216 && temp3 == 255 && temp4 == 225)  {
            uint8_t *start = data; //same test as the loops above, but taking into account the other possible beginning signature
            while(loop2 != 1){
                temp1 = *data;
                temp2 = *(data+1);
                temp3 = *(data+2);
                if(temp1 == 255 && temp2 == 217 && temp3 == 0){
                    sprintf(fileName, "%03d.jpg", numFiles);
                    save_jpeg(start, count, fileName);
                    numFiles++;
                    loop2 = 1;
                }else{
                    data++;
                    count++;
                }
            }
        }
        loop1++;
        data++;
    }
}
//P.S. could not get all images to appear, if it's an error in my code could I please get a hint into what it is I'm forgetting to consider?