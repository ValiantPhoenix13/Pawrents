#include <stdio.h>

int bills(int x);
int getAmount();


int main(){
    int amount;
    amount = getAmount();
    int count = bills(amount);
    printf("You will get %d bill(s) back. \n", count);
}

int getAmount(){
    int amount;
    printf("Please provide a positive integer to break down into bills: ");
    scanf("%d", &amount);
    while (amount <= 0){
        printf("Only give a postive integer: ");
        scanf("%d", &amount);
    }
    return amount;
}

int bills(int x){
    int count = 0;
    int temp;
    if (x >= 100){
        count = count + (x / 100);
        temp = x / 100;
        x = x - (temp * 100);
    }
    if (x >= 20){
        count = count + (x / 20);
        temp = x / 20;
        x = x - (temp * 20);
    }
    if (x >= 10){
        count = count + (x / 10);
        temp = x / 10;
        x = x - (temp * 10);
    }
    if (x >= 5){
        count = count + (x / 5);
        temp = x / 5;
        x = x - (temp * 5);
    }
    if (x >= 1){
        count = count + (x / 1);
        temp = x / 1;
        x = x - (temp * 1);
    }
    return count;
}
